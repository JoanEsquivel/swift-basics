import Foundation

let myNumber = 4

if myNumber < 10 && myNumber > 5{
    print("\(myNumber) is less than 10 and greather than 5")
}else if myNumber < 10{
    print("\(myNumber) is less than 10")
}
else{
    print("Not meeting the if statement")
}


