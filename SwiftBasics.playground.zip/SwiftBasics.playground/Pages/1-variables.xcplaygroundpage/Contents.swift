import UIKit

//Based on
//*https://www.youtube.com/watch?v=P6ko_I5GHbs *//

//Variables
/*I am a comment*/
var myFirstVariable = "Hello Joan"


print(myFirstVariable)

//You cannot assing a new type, such a number.
myFirstVariable = "Hello Joan Overwrited"
print(myFirstVariable)

//Constants
let myFirstConstant = "Hello World Constant"
//The value can not be over writed.
print (myFirstConstant)
