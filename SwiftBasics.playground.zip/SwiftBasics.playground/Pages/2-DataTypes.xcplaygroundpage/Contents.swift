import UIKit

//Simple data types

//String
let myString:String = "Hello there"
let myString2 = "My name is Joan"
let myString3 = myString + " " + myString2
print(myString3)

//Int
let myInt:Int = 1
let myInt2 = 2
print (myInt + myInt2)

//Double
let myDouble = 1.5
let myDouble2 = 2.5
print(myDouble + myDouble2)

//Float
//By default is double
let myFloat:Float = 1.5
let myFloat2:Float = 1.5
print(myFloat + myFloat2)

//Boolean
let myBool:Bool = true
let myBool2 = false

print(myBool && myBool2)
